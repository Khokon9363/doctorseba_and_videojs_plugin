function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}

// Menu Toggle Script
$(document).ready(function () {
    $('.sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });
});

// Outside hide
// window.onload=function() {
//     var hideDiv = document.getElementById('mySidenav');
//     document.onclick=function(div){
//         if(div.target.id !== 'mySidenav') {
//             hideDiv.style.display='none';
//         }
//     }
// }